import React from 'react';

function Video() {
  return (
    <div>
      <h2>Video Consultation</h2>
      <button>Start Video Call</button>
    </div>
  );
}

export default Video;
