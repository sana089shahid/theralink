import React from 'react';
import SignUp from './SignUp';
import SignIn from './SignIn';
import Video from './Video';
import Chat from './Chat';
import Notification from './Notification';

function App() {
  return (
    <div>
      <h1>TheraLink App</h1>
      <SignUp />
      <SignIn />
      <Video />
      <Chat />
      <Notification />
    </div>
  );
}

export default App;
