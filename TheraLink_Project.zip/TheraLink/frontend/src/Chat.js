import React, { useState } from 'react';

function Chat() {
  const [msg, setMsg] = useState("");
  const [chat, setChat] = useState([]);

  const sendMsg = () => {
    setChat([...chat, msg]);
    setMsg("");
  };

  return (
    <div>
      <h2>Chat</h2>
      <input value={msg} onChange={e => setMsg(e.target.value)} />
      <button onClick={sendMsg}>Send</button>
      <ul>{chat.map((m, i) => <li key={i}>{m}</li>)}</ul>
    </div>
  );
}

export default Chat;
