import React, { useEffect, useState } from 'react';
import axios from 'axios';

function Notification() {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/notifications/testuser')
      .then(res => setAlerts(res.data));
  }, []);

  return (
    <div>
      <h2>Alerts</h2>
      <ul>
        {alerts.map((a, i) => <li key={i}>{a.message}</li>)}
      </ul>
    </div>
  );
}

export default Notification;
