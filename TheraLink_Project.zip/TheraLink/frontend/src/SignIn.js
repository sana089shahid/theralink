import React, { useState } from 'react';
import axios from 'axios';

function SignIn() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const login = () => {
    axios.post('http://localhost:5000/api/auth/login', {
      email,
      password
    }).then(res => alert("Login Success: " + res.data.token));
  };

  return (
    <div>
      <h2>Sign In</h2>
      <input onChange={e => setEmail(e.target.value)} placeholder="Email" />
      <input onChange={e => setPassword(e.target.value)} type="password" placeholder="Password" />
      <button onClick={login}>Login</button>
    </div>
  );
}

export default SignIn;
