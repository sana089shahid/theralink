import React, { useState } from 'react';
import axios from 'axios';

function SignUp() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const register = () => {
    axios.post('http://localhost:5000/api/auth/register', {
      email,
      password,
      role: 'user'
    }).then(res => alert(res.data));
  };

  return (
    <div>
      <h2>Sign Up</h2>
      <input onChange={e => setEmail(e.target.value)} placeholder="Email" />
      <input onChange={e => setPassword(e.target.value)} type="password" placeholder="Password" />
      <button onClick={register}>Register</button>
    </div>
  );
}

export default SignUp;
