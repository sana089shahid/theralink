const express = require('express');
const router = express.Router();
const Notification = require('../models/Notification');

router.post('/', async (req, res) => {
  const notif = new Notification(req.body);
  await notif.save();
  res.send("Notification saved");
});

router.get('/:user', async (req, res) => {
  const notifs = await Notification.find({ user: req.params.user });
  res.json(notifs);
});

module.exports = router;
